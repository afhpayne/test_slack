long long strtonum(const char *, long long, long long, const char **);
