#define	pledge(promises, execpromises)	(0)
